const o=typeof window<"u"?window:typeof globalThis<"u"?globalThis:global;export{o as g};
