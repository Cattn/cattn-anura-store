const a=""+new URL("../assets/GBA_3_main.DcG64Xi-.png",import.meta.url).href;export{a as m};
