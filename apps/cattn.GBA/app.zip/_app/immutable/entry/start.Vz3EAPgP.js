import{a as t}from"../chunks/entry.DypRryQK.js";export{t as start};
